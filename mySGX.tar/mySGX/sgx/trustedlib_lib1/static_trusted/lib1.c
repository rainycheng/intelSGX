#include "lib1_t.h"  /* print_string */

int ecall_lib1_sample()
{
  return 0;
}

